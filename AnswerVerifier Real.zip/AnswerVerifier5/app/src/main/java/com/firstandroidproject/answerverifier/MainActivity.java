package com.firstandroidproject.answerverifier;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
   EditText _txtUser, _txtPass;
   Spinner  _spinner;
   Button  _btnLogin;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        _txtPass=(EditText)findViewById(R.id.txtPass);
        _txtUser=(EditText)findViewById(R.id.txtUser);
        _btnLogin=(Button) findViewById(R.id.btnLogin);
        _spinner=(Spinner)findViewById(R.id.spinner);
        ArrayAdapter <CharSequence> adapter = ArrayAdapter.createFromResource(this , R.array.SelectUserType,R.layout.support_simple_spinner_dropdown_item);
        _spinner.setAdapter(adapter);
        _btnLogin.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v)
            {
                String item = _spinner.getSelectedItem().toString();
                if (_txtUser.getText().toString().equals("Teacher")&&_txtPass.getText().toString().equals("Teacher")&& item.equals("Teacher"))
                {
                        Intent intent = new Intent(MainActivity.this,Teacher.class);
                        startActivity(intent);

                }else if(_txtUser.getText().toString().equals("Student")&&_txtPass.getText().toString().equals("Student")&& item.equals("Student"))

                {
                Intent intent = new Intent(MainActivity.this,Student.class);
                startActivity(intent);

                }else {
                    Toast.makeText(getApplicationContext(),"Error",Toast.LENGTH_LONG).show();

                }





            }
    });
    }
}

